import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

st.set_page_config(
    page_title="Facility Reservation Decision Support",
    page_icon="🏫",
    layout="wide"
)

sns.set_theme(style="whitegrid")
np.random.seed(42)


@st.cache_data
def generate_sample_data(n_samples=400):
    """Generate synthetic sample reservations based on the original notebook."""
    data = {
        "Reservation_ID": [f"RES-{1000+i}" for i in range(n_samples)],
        "User_Category": np.random.choice(
            ["Student", "Faculty", "Staff", "Student Org", "student"],
            size=n_samples, p=[0.4, 0.25, 0.15, 0.15, 0.05]
        ),
        "Facility_Type": np.random.choice(
            ["Auditorium", "Lab", "Conference Room", "Lecture Hall"],
            size=n_samples
        ),
        "Lead_Time_Days": np.random.choice(
            [0, 1, 2, 5, 10, 20, -5, 999], size=n_samples,
            p=[0.15, 0.15, 0.1, 0.25, 0.2, 0.12, 0.01, 0.02]
        ),
        "Participants": np.random.choice(
            [10, 20, 50, 100, 0, -10], size=n_samples,
            p=[0.3, 0.3, 0.2, 0.15, 0.03, 0.02]
        ),
        "Actual_Attendance": np.random.choice(
            [10, 18, 45, 0, np.nan], size=n_samples,
            p=[0.3, 0.3, 0.2, 0.15, 0.05]
        ),
        "Usage_Status": np.random.choice(
            ["Used", "Cancelled", "No-Show"], size=n_samples,
            p=[0.6, 0.25, 0.15]
        ),
        "Cancellation_Days_Before": np.random.choice(
            [0, 1, 3, 5, np.nan], size=n_samples,
            p=[0.1, 0.1, 0.1, 0.1, 0.6]
        )
    }
    df = pd.DataFrame(data)
    # Match the original notebook's intentional duplicate-row exercise.
    df = pd.concat([df, df.iloc[:5]], ignore_index=True)
    return df


def clean_and_engineer(raw):
    df = raw.copy()
    original_rows = len(df)
    missing_before = df.isna().sum()
    duplicate_count = int(df.duplicated().sum())
    df = df.drop_duplicates().reset_index(drop=True)

    df["User_Category"] = df["User_Category"].replace({
        "student": "Student", "STUDENT": "Student",
        "student org": "Student Org"
    })

    invalid_lead = (df["Lead_Time_Days"] < 0) | (df["Lead_Time_Days"] > 180)
    invalid_participants = df["Participants"] <= 0
    invalid_lead_count = int(invalid_lead.sum())
    invalid_participant_count = int(invalid_participants.sum())

    df.loc[invalid_lead, "Lead_Time_Days"] = np.nan
    df.loc[invalid_participants, "Participants"] = np.nan
    df["Lead_Time_Days"] = df["Lead_Time_Days"].fillna(df["Lead_Time_Days"].median())
    df["Participants"] = df["Participants"].fillna(df["Participants"].median())

    def categorize_lead_time(days):
        if days <= 2:
            return "Last Minute"
        if days <= 7:
            return "Short Lead"
        if days <= 14:
            return "Medium Lead"
        return "Early Booking"

    df["Lead_Time_Category"] = df["Lead_Time_Days"].apply(categorize_lead_time)
    df["Reservation_Outcome"] = np.where(
        df["Usage_Status"].eq("Used"), "Completed", "Not Completed"
    )
    df["Attendance_Ratio"] = np.where(
        df["Actual_Attendance"].isna() | df["Participants"].isna() |
        df["Participants"].eq(0),
        0.0,
        df["Actual_Attendance"] / df["Participants"]
    )

    summary = {
        "original_rows": original_rows,
        "rows_after_dedup": len(df),
        "duplicate_rows_removed": duplicate_count,
        "invalid_lead_times": invalid_lead_count,
        "invalid_participants": invalid_participant_count,
        "missing_before": missing_before
    }
    return df, summary


@st.cache_resource
def train_model(df):
    features = [
        "User_Category", "Facility_Type", "Lead_Time_Days",
        "Participants", "Lead_Time_Category"
    ]
    X = pd.get_dummies(df[features], drop_first=True)
    y = df["Reservation_Outcome"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    metrics = {
        "Accuracy": accuracy_score(y_test, predictions),
        "Precision (Not Completed)": precision_score(
            y_test, predictions, pos_label="Not Completed", zero_division=0
        ),
        "Recall (Not Completed)": recall_score(
            y_test, predictions, pos_label="Not Completed", zero_division=0
        ),
        "F1 (Not Completed)": f1_score(
            y_test, predictions, pos_label="Not Completed", zero_division=0
        )
    }
    cm = confusion_matrix(
        y_test, predictions, labels=["Completed", "Not Completed"]
    )
    cm_df = pd.DataFrame(
        cm,
        index=["Actual Completed", "Actual Not Completed"],
        columns=["Predicted Completed", "Predicted Not Completed"]
    )
    report = classification_report(y_test, predictions, output_dict=True, zero_division=0)
    importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)
    return model, list(X.columns), metrics, cm_df, report, importances


st.title("🏫 Facility Reservation Decision-Support System")
st.caption("Streamlit conversion of the uploaded facility-reservation data-mining notebook.")
st.warning(
    "Predictions are decision-support estimates only. Do not automatically approve or reject "
    "reservations based on this model. The built-in data is synthetic."
)

with st.sidebar:
    st.header("Navigation")
    page = st.radio(
        "Choose a module",
        ["Dashboard", "Dataset & Cleaning", "Exploratory Analysis", "Model Evaluation", "Predict Outcome"],
        index=0
    )
    st.divider()
    st.caption("Built with synthetic demonstration data. Upload authorized data only.")

raw_df = generate_sample_data()
clean_df, cleaning_summary = clean_and_engineer(raw_df)
model, model_columns, metrics, cm_df, report, importances = train_model(clean_df)

if page == "Dashboard":
    st.subheader("Overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Raw rows", f"{len(raw_df):,}")
    c2.metric("Clean rows", f"{len(clean_df):,}")
    c3.metric("Facilities", clean_df["Facility_Type"].nunique())
    c4.metric("Completion rate", f"{(clean_df['Reservation_Outcome'].eq('Completed').mean() * 100):.1f}%")

    left, right = st.columns(2)
    with left:
        counts = clean_df["Facility_Type"].value_counts()
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.barplot(x=counts.index, y=counts.values, ax=ax)
        ax.set_title("Reservations by Facility Type")
        ax.set_xlabel("Facility Type")
        ax.set_ylabel("Number of Reservations")
        ax.tick_params(axis="x", rotation=20)
        st.pyplot(fig)
        plt.close(fig)
    with right:
        outcome = pd.crosstab(
            clean_df["Lead_Time_Category"], clean_df["Reservation_Outcome"],
            normalize="index"
        ) * 100
        fig, ax = plt.subplots(figsize=(7, 4))
        outcome.plot(kind="bar", ax=ax)
        ax.set_title("Outcome Percentage by Lead-Time Category")
        ax.set_xlabel("Lead-Time Category")
        ax.set_ylabel("Reservations (%)")
        ax.legend(title="Outcome")
        ax.tick_params(axis="x", rotation=20)
        st.pyplot(fig)
        plt.close(fig)

    st.subheader("Quick insights")
    top_facility = clean_df["Facility_Type"].value_counts().idxmax()
    st.write(f"- Most frequently reserved facility type in this sample: **{top_facility}**.")
    st.write("- Compare lead-time groups and user categories before making operational changes.")
    st.write("- This dataset is randomly generated and should not be treated as evidence about real campus demand.")

elif page == "Dataset & Cleaning":
    st.subheader("Raw synthetic dataset")
    st.dataframe(raw_df.head(20), use_container_width=True)
    st.download_button(
        "Download raw CSV",
        raw_df.to_csv(index=False).encode("utf-8"),
        file_name="facility_reservations.csv",
        mime="text/csv"
    )

    st.subheader("Cleaning summary")
    a, b, c, d = st.columns(4)
    a.metric("Original rows", cleaning_summary["original_rows"])
    b.metric("Duplicate rows removed", cleaning_summary["duplicate_rows_removed"])
    c.metric("Invalid lead-time values", cleaning_summary["invalid_lead_times"])
    d.metric("Invalid participant values", cleaning_summary["invalid_participants"])

    st.write("Missing values in raw data")
    st.dataframe(cleaning_summary["missing_before"].rename("Missing values").to_frame())
    st.write("Cleaned and engineered data")
    st.dataframe(clean_df.head(30), use_container_width=True)
    st.download_button(
        "Download cleaned CSV",
        clean_df.to_csv(index=False).encode("utf-8"),
        file_name="cleaned_facility_reservations.csv",
        mime="text/csv"
    )
    st.info(
        "Cleaning removes duplicate rows, standardizes user categories, treats lead times outside "
        "0–180 days and participant counts at or below zero as invalid, then imputes those numeric "
        "values with the median."
    )

elif page == "Exploratory Analysis":
    st.subheader("Exploratory Data Analysis")
    tab1, tab2, tab3 = st.tabs(["Facility counts", "Outcome by user", "Outcome by lead time"])
    with tab1:
        counts = clean_df["Facility_Type"].value_counts().rename_axis("Facility Type").reset_index(name="Reservations")
        st.dataframe(counts, use_container_width=True)
        fig, ax = plt.subplots(figsize=(9, 4))
        sns.barplot(data=counts, x="Facility Type", y="Reservations", ax=ax)
        ax.set_title("Total Reservation Count by Facility Type")
        ax.set_xlabel("Facility Type")
        ax.set_ylabel("Number of Reservations")
        st.pyplot(fig)
        plt.close(fig)
    with tab2:
        user_outcome = pd.crosstab(
            clean_df["User_Category"], clean_df["Reservation_Outcome"], normalize="index"
        ) * 100
        st.dataframe(user_outcome.round(2), use_container_width=True)
        st.bar_chart(user_outcome)
    with tab3:
        lead_outcome = pd.crosstab(
            clean_df["Lead_Time_Category"], clean_df["Reservation_Outcome"], normalize="index"
        ) * 100
        st.dataframe(lead_outcome.round(2), use_container_width=True)
        fig, ax = plt.subplots(figsize=(9, 4))
        lead_outcome.plot(kind="bar", ax=ax)
        ax.set_title("Reservation Outcome Proportions by Lead Time")
        ax.set_xlabel("Lead-Time Category")
        ax.set_ylabel("Reservations (%)")
        ax.legend(title="Reservation Outcome")
        ax.tick_params(axis="x", rotation=20)
        st.pyplot(fig)
        plt.close(fig)

    st.markdown("**Management implication:** Use these summaries to identify facility demand and compare completion patterns. Because the records are synthetic, validate any apparent pattern with authorized operational data before making decisions.")

elif page == "Model Evaluation":
    st.subheader("Decision-tree model performance")
    cols = st.columns(4)
    for col, (name, value) in zip(cols, metrics.items()):
        col.metric(name, f"{value:.3f}")

    st.write("Confusion matrix")
    st.dataframe(cm_df, use_container_width=True)
    st.write("Classification report")
    st.dataframe(pd.DataFrame(report).transpose().round(3), use_container_width=True)

    st.write("Top feature importances")
    st.dataframe(
        importances.head(10).rename("Importance").to_frame(),
        use_container_width=True
    )
    fig, ax = plt.subplots(figsize=(18, 8))
    plot_tree(
        model, feature_names=model_columns, class_names=list(model.classes_),
        filled=True, rounded=True, fontsize=8, ax=ax
    )
    ax.set_title("Decision Tree: Reservation Outcome")
    st.pyplot(fig)
    plt.close(fig)

    st.caption(
        "Metrics are calculated from a random 20% holdout split of the synthetic dataset. "
        "Performance on real reservation data may differ."
    )

elif page == "Predict Outcome":
    st.subheader("Predict a reservation outcome")
    st.write("Enter reservation details to see the model's estimated outcome.")
    with st.form("prediction_form"):
        c1, c2 = st.columns(2)
        with c1:
            user_category = st.selectbox(
                "User category", ["Student", "Faculty", "Staff", "Student Org"]
            )
            facility_type = st.selectbox(
                "Facility type", ["Auditorium", "Lab", "Conference Room", "Lecture Hall"]
            )
            lead_time = st.number_input(
                "Lead time (days)", min_value=0, max_value=180, value=5, step=1
            )
        with c2:
            participants = st.number_input(
                "Participants", min_value=1, max_value=1000, value=20, step=1
            )
            st.caption("The model uses these details plus a lead-time category.")
        submitted = st.form_submit_button("Predict outcome", type="primary")

    if submitted:
        if lead_time <= 2:
            lead_category = "Last Minute"
        elif lead_time <= 7:
            lead_category = "Short Lead"
        elif lead_time <= 14:
            lead_category = "Medium Lead"
        else:
            lead_category = "Early Booking"

        input_df = pd.DataFrame([{
            "User_Category": user_category,
            "Facility_Type": facility_type,
            "Lead_Time_Days": float(lead_time),
            "Participants": float(participants),
            "Lead_Time_Category": lead_category
        }])
        encoded_input = pd.get_dummies(input_df, drop_first=True)
        encoded_input = encoded_input.reindex(columns=model_columns, fill_value=0)
        prediction = model.predict(encoded_input)[0]
        probabilities = model.predict_proba(encoded_input)[0]
        probability_df = pd.DataFrame({
            "Outcome": model.classes_,
            "Model probability": probabilities
        }).sort_values("Model probability", ascending=False)

        if prediction == "Completed":
            st.success("Estimated outcome: Completed")
        else:
            st.info("Estimated outcome: Not Completed")
        st.dataframe(probability_df, use_container_width=True)
        st.caption(
            "This is a model estimate, not an approval or rejection decision. Review the request "
            "using the institution's normal policy and human process."
        )
