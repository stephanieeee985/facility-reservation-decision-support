# Facility Reservation Decision-Support System (Streamlit)

This is a Streamlit version of the uploaded facility reservation notebook/script.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   streamlit run app.py
   ```

The app generates synthetic sample records based on the original code, so it does not need a separate CSV to start. It includes dashboard, data cleaning, exploratory analysis, model evaluation, and prediction modules.

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository and upload `app.py`, `requirements.txt`, and this README.
2. In Streamlit Community Cloud, choose **Create app** and connect the repository.
3. Select `app.py` as the main file and deploy.

## Important limitation

The built-in data is synthetic. Model predictions are for demonstration and decision support only; they should not automatically approve or reject a real reservation.
